# Lab 5: Static Code Analysis — Issue Documentation

**Repository:** L5_57_loan-eligibility  
**Source file:** loan_calculator.py

## Issues Identified and Fixed

| Issue | Type | Original Line(s) | Description | Fix Approach |
|---|---|---|---|---|
| Mutable default argument | Bug | 20 | The default list `history=[]` was shared across function calls. | Replaced the mutable default with `None` and removed unnecessary state from the eligibility check. |
| Incorrect EMI calculation | Logic bug | 14–18 | The annual interest rate was not converted correctly to a monthly decimal rate. | Converted the annual percentage to a monthly rate using `annual_rate / 100 / 12` and handled zero interest separately. |
| Incorrect eligibility decision | Logic bug | 20–31 | The eligibility condition could approve applicants without satisfying all required criteria. | Added explicit checks for age, income, credit score, loan type, and EMI-to-income ratio. |
| Incorrect maximum-loan calculation | Logic bug | 33–38 | The calculation did not correctly account for interest over the loan tenure. | Used a present-value formula based on affordable monthly payments. |
| Unsafe binary deserialization | Security | 4, 61–65 | The original program used `marshal` to load stored application records. | Replaced binary serialization with JSON and validated the loaded data. |
| Hard-coded FTP credentials | Security | 67–71 | A password was embedded in the source code. | Removed the hard-coded credentials and removed the FTP upload functionality from the revised program. |
| Insecure FTP usage | Security | 3, 68–71 | The original code used an unencrypted FTP connection. | Removed the FTP-related code from the revised program. |
| Predictable application identifiers | Security | 5, 51 | The original program used a general-purpose random number generator for application IDs. | Used the `secrets` module to generate less predictable identifiers. |
| Incorrect risk-band classification | Logic bug | 81–91 | A credit score above the expected range could be classified as LOW risk. | Validated the expected score range before assigning a risk band. |
| File handling and resource management | Code quality | 56–65, 70 | Files were opened without consistently using context managers. | Used `with` statements to manage file resources safely. |
| Naming and documentation issues | Code quality | Throughout | Function names and documentation did not consistently follow Python conventions. | Used `snake_case`, added docstrings, and improved code structure. |
| Formatting violations | Style | Throughout | The original code contained long lines, excessive or missing blank lines, and an unused import. | Applied formatting corrections and verified the result using Flake8. |

## Verification Results

| Tool | Before Fixes | After Fixes |
|---|---|---|
| Pylint | 5.17/10 | 9.84/10 |
| Bandit | 8 findings: 2 high, 1 medium, 5 low | 0 findings |
| Flake8 | 22 violations | 0 violations |

The corrected program compiled successfully. Functional tests confirmed the zero-interest EMI calculation, rejection of an applicant whose existing EMIs exceeded the configured FOIR limit, and rejection of an out-of-range credit score.

**Note:** The original line numbers refer to the original source file. The issue list includes findings from both static analysis and manual code review. The FTP upload functionality was removed rather than retained as a secured upload implementation.