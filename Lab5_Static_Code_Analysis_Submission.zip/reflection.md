# Lab 5: Static Code Analysis — Reflection

## 1. What is static code analysis, and why is it important?

Static code analysis examines source code without executing the program. It helps identify potential bugs, security vulnerabilities, code-quality problems, and style violations early in development. It improves maintainability and helps developers detect problems before software is deployed.

## 2. What are the differences between Pylint, Bandit, and Flake8?

Pylint analyses Python code quality, naming conventions, potential programming errors, and design issues. Bandit identifies common security weaknesses, including unsafe deserialization and insecure functions. Flake8 checks Python style and formatting, including line length, indentation, blank lines, and unused imports. Using all three provides broader coverage than relying on a single tool.

## 3. What issues were identified and how were they resolved?

The original program contained incorrect loan calculations, an eligibility-checking defect, a mutable default argument, unsafe binary deserialization, hard-coded FTP credentials, and formatting violations. The calculations and input validation were corrected, JSON was introduced for application storage, and the FTP upload functionality was removed. Naming, documentation, and formatting were also improved.

## 4. What did you learn from this lab?

I learned that a program can execute without crashing and still produce incorrect results. Functional testing helped expose errors in the EMI calculation, eligibility decision, and risk classification. Static analysis provided additional feedback about code quality, security, and style. However, static-analysis tools cannot guarantee logical correctness, so they should be combined with functional testing and code review.

## Final Results

- Pylint score improved from 5.17/10 to 9.84/10.
- Bandit findings decreased from eight to zero.
- Flake8 findings decreased from 22 to zero.
- Python compilation completed successfully.

These results demonstrate how static analysis and functional testing can improve code quality, security, and maintainability.

**Note:** These are general reflection answers. The supplied lab handout refers to reflection questions but does not include their exact wording, so the answers should be matched to the instructor's actual questions if they are provided separately.