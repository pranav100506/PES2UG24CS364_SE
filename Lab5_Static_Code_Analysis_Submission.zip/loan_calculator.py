"""Loan eligibility and EMI calculator for Lab 5 static code analysis."""

import json
import logging
import os
import secrets
import smtplib
from datetime import datetime, timezone
from email.message import EmailMessage

from pathlib import Path
from typing import Any

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
)
LOGGER = logging.getLogger(__name__)

MAX_FOIR = 0.50
DEFAULT_APPLICATION_FILE = Path("loans.json")
BUREAU_HOST = os.getenv("BUREAU_HOST", "")


def _validate_loan_inputs(
    principal: float, annual_rate: float, years: int
) -> None:
    """Validate the common inputs used by loan calculations."""
    if principal <= 0:
        raise ValueError("Principal must be greater than zero.")
    if annual_rate < 0:
        raise ValueError("Annual interest rate cannot be negative.")
    if years <= 0:
        raise ValueError("Loan tenure must be greater than zero.")


def calculate_emi(principal: float, annual_rate: float, years: int) -> float:
    """Return monthly EMI. annual_rate is expressed as a percentage."""
    _validate_loan_inputs(principal, annual_rate, years)
    monthly_rate = annual_rate / 100 / 12
    months = years * 12
    if monthly_rate == 0:
        return principal / months
    factor = (1 + monthly_rate) ** months
    return principal * monthly_rate * factor / (factor - 1)


def check_eligibility(
    age: int,
    income: float,
    credit_score: int,
    existing_emi: float,
    loan_type: str,
    history: list[str] | None = None,
) -> bool:
    """Check eligibility using basic illustrative rules.

This is not a lender approval decision.
"""
    if history is not None:
        history.append(loan_type)

    valid_loan_types = {"home", "car", "personal"}
    if age < 21 or age > 60 or income <= 0 or existing_emi < 0:
        return False
    if loan_type not in valid_loan_types:
        return False
    if credit_score < 700:
        return False
    if existing_emi / income > MAX_FOIR:
        return False
    return True


def max_loan_amount(
    income: float, existing_emi: float, annual_rate: float, years: int
) -> float:
    """Estimate principal affordable under the selected EMI-to-income limit."""
    if income <= 0 or existing_emi < 0:
        raise ValueError(
            "Income must be positive and existing EMI non-negative.")
    _validate_loan_inputs(1, annual_rate, years)
    available_emi = max(0.0, income * MAX_FOIR - existing_emi)
    monthly_rate = annual_rate / 100 / 12
    months = years * 12
    if monthly_rate == 0:
        return available_emi * months
    factor = (1 + monthly_rate) ** months
    return available_emi * (factor - 1) / (monthly_rate * factor)


def amortisation_schedule(
    principal: float, annual_rate: float, years: int
) -> list[tuple[int, float, float]]:
    """Return (month, interest, remaining balance) for each month."""
    emi = calculate_emi(principal, annual_rate, years)
    monthly_rate = annual_rate / 100 / 12
    balance = principal
    rows = []
    for month in range(1, years * 12 + 1):
        interest = balance * monthly_rate
        principal_paid = min(balance, emi - interest)
        balance = max(0.0, balance - principal_paid)
        rows.append((month, round(interest, 2), round(balance, 2)))
    return rows


def application_id() -> str:
    """Generate a non-predictable application identifier."""
    return f"LN-{secrets.token_hex(4).upper()}"


def save_application(
    name: str,
    amount: float,
    file_path: Path = DEFAULT_APPLICATION_FILE,
) -> str:
    """Save application records as JSON.

    Avoid unsafe binary deserialization.
    """
    if not name.strip():
        raise ValueError("Applicant name cannot be empty.")
    if amount <= 0:
        raise ValueError("Loan amount must be greater than zero.")

    applications = load_applications(file_path)
    app_id = application_id()
    applications[app_id] = {
        "name": name.strip(),
        "amount": round(amount, 2),
        "date": datetime.now(timezone.utc).isoformat(),
    }
    file_path.write_text(
        json.dumps(applications, indent=2),
        encoding="utf-8",
    )
    return app_id


def load_applications(
    file_path: Path = DEFAULT_APPLICATION_FILE,
) -> dict[str, Any]:
    """Load application records from a JSON file.

    Return an empty dictionary if the file does not exist.
    """
    if not file_path.exists():
        return {}

    try:
        data = json.loads(
            file_path.read_text(encoding="utf-8")
        )
    except (json.JSONDecodeError, OSError) as exc:
        raise ValueError(
            f"Could not read application file: {file_path}"
        ) from exc

    if not isinstance(data, dict):
        raise ValueError(
            "Application file must contain a JSON object."
        )

    return data


def notify_applicant(email_address: str, status: str) -> None:
    """Send a notification using SMTP configuration from the environment."""
    smtp_host = os.getenv("SMTP_HOST")
    sender = os.getenv("SMTP_SENDER")
    if not smtp_host or not sender:
        raise RuntimeError("Configure SMTP_HOST and SMTP_SENDER first.")

    message = EmailMessage()
    message["Subject"] = f"Loan {status}"
    message["From"] = sender
    message["To"] = email_address
    message.set_content(f"Your loan application status is: {status}.")
    with smtplib.SMTP(smtp_host, timeout=15) as smtp:
        smtp.send_message(message)


def interest_saved(
    principal: float, annual_rate: float, years: int, prepayment: float
) -> float:
    """Estimate interest saved by reducing principal before the loan starts."""
    _validate_loan_inputs(principal, annual_rate, years)
    if prepayment < 0 or prepayment >= principal:
        raise ValueError(
            "Prepayment must be non-negative and less than principal.")
    original_total = calculate_emi(principal, annual_rate, years) * years * 12
    reduced_total = (
        calculate_emi(principal - prepayment, annual_rate, years) * years * 12
    )
    return max(0.0, original_total - reduced_total)


def risk_band(credit_score: int) -> str:
    """Map a plausible credit score to an illustrative risk band."""
    if not 300 <= credit_score <= 900:
        return "INVALID"
    if credit_score >= 800:
        return "LOW"
    if credit_score >= 700:
        return "MEDIUM"
    if credit_score >= 600:
        return "HIGH"
    return "VERY HIGH"


def main() -> None:
    """Run a small demonstration of the calculator."""
    LOGGER.info("EMI for ₹500,000 at 9%% for 5 years: %.2f",
                calculate_emi(500000, 9, 5))
    LOGGER.info(
        "Eligible (score 760): %s",
        check_eligibility(35, 40000, 760, 5000, "personal"),
    )
    LOGGER.info("Max loan for income ₹40,000: %.2f",
                max_loan_amount(40000, 5000, 9, 5))
    LOGGER.info("Risk band for 850: %s", risk_band(850))
    LOGGER.info("Interest saved estimate: %.2f",
                interest_saved(500000, 9, 5, 50000))
    app_id = save_application("Anil", 500000)
    LOGGER.info("Saved application: %s", app_id)
    LOGGER.info("Applications on file: %d", len(load_applications()))


if __name__ == "__main__":
    main()
